Command:
python3 p[7 or 8].py

就會做出相對應的圖片：
"img_[7 or 8].png"

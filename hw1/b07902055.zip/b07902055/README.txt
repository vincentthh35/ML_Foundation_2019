g++ 編譯 6.cpp、7.cpp、8.cpp 並執行之後，會跑出 result_6、result_7、result_8
python3 plot_6、plot_7.py、plot_8.py